package com.ob.service;

import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import com.ob.dao.IOnlineBankingDao;
import com.ob.dao.OnlineBankingDao;
import com.ob.dtobean.AccountMaster;
import com.ob.dtobean.CustomerSignUp;
import com.ob.dtobean.NewAccount;
import com.ob.dtobean.Payee;
import com.ob.dtobean.ServiceTracker;
import com.ob.dtobean.Transaction;
import com.ob.exception.OnlineBankingException;

public class OnlineBankingService implements IOnlineBankingService
{
	 static Scanner sc=new Scanner(System.in);
	static IOnlineBankingDao daoobj;

	public OnlineBankingService() {
		daoobj=new OnlineBankingDao();
	}
	
	@Override
	public CustomerSignUp validateCustomerLoginDetails(int custuserid, String custpassword) throws OnlineBankingException {
	
		return daoobj.validateCustomerLoginDetails(custuserid,custpassword);
	}
	
	@Override
	public int customerOpeningBalance(int loginId) throws OnlineBankingException {
		
		daoobj=new OnlineBankingDao();
		return daoobj.customerOpeningBalance(loginId);
	}
	
	//Request for servicetracker
	@Override
	public int request(int accountId, String description) throws OnlineBankingException {
		daoobj=new OnlineBankingDao();
		
		return daoobj.request(accountId,description);
	}
	
	public String retrieveServiceTrackerByAccountId(int accountId) throws OnlineBankingException{
		daoobj=new OnlineBankingDao();
		return daoobj.retrieveServiceTrackerByAccountId(accountId);
		
	}
	
	@Override
	public int customerSignUp(CustomerSignUp  obs) throws OnlineBankingException {
		return daoobj.customerSignUp(obs);
		
	}
	@Override
    public int updateLoginPassword(int userid,String loginPassword) throws OnlineBankingException {
		return daoobj.updateLoginPassword(userid,loginPassword);
	}
	@Override
	public int serviceTrackerId(int accountId,String newCheck) throws OnlineBankingException {
		daoobj=new OnlineBankingDao();
		return daoobj.serviceTrackerId(accountId,newCheck);
	}


	//validation method for user
	
	@Override
	public boolean validateUserId(int userId) {
		Pattern pattern=Pattern.compile("\\d[1-9][0-9]{5}");
		String userid=Integer.toString(userId);
		Matcher matcher=pattern.matcher(userid);
		if(matcher.equals(userid))
		{
			return true;	
		}
		else{
			System.err.println("Please Enter Valid User Id");
			return false;	
		}
		
	}


	@Override
	public boolean validateLoginPassword(String loginPassword) {
		Pattern pattern=Pattern.compile( "(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=])(?=\\S+$).{8,}");
		Matcher matcher=pattern.matcher(loginPassword);
		if(matcher.equals(loginPassword))
		{
			return true;	
		}
		else{
			System.err.println("Please Enter Valid Login Password");
			System.out.println("Password should have minimum 1 upper case  1 lower case followed by 1 special character and number");
			return false;	
		}
	}


	@Override
	public boolean validateSecretQuestion(String secretQuestion)
	{
		Pattern pattern=Pattern.compile("");
		Matcher matcher=pattern.matcher(secretQuestion);
		if(matcher.equals(secretQuestion))
		{
			return true;	
		}
		else{
			System.err.println("Please Enter Valid Secret Question");
			return false;	
		}
	}


	@Override
	public boolean validateTransactionPassword(String transactionPassword) {
		Pattern pattern=Pattern.compile( "(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=])(?=\\S+$).{8,}");
		
		Matcher matcher=pattern.matcher(transactionPassword);
		if(matcher.equals(transactionPassword))
		{
			return true;	
		}
		else{
			System.err.println("Please Enter Valid TransactionPassword ");
			System.out.println("Password should have minimum 1 upper case  1 lower case followed by 1 special character and number");
			return false;	
		}
	}
    @Override
	public boolean validatename(String name) {
		 Pattern pattern=Pattern.compile("[A-Z][a-z]{2,15}");
		   Matcher matcher=pattern.matcher(name);
		   if(matcher.matches()) {
		  // log.info("Name Matches"+name);
		    return true;
		   }
		   else
		   {
		   // log.info("Name is not matching");
		    return false;
		   }
		
		
	}


	@Override
	public boolean validatemobileNo(String mobileNo) {
		 Pattern pattern=Pattern.compile("{1}[6-9][0-9]{9}");
		   Matcher matcher=pattern.matcher( mobileNo);
		   if(matcher.matches()) {
		  // log.info("mobile number Matches"+ mobileNumber);
		    return true;
		   }
		   else
		   {
		  //  log.info("moblie number is not matching");
		    return false;
		   }
	}


	@Override
	public boolean validatePanCard(String panCard) {
		Pattern pattern=Pattern.compile("[a-zA-Z1-9]{10}");
		   Matcher matcher=pattern.matcher( panCard);
		   if(matcher.matches()) {
		   //log.info("panCard Matches"+panCard);
		    return true;
		   }
		   else
		   {
		    //log.info("pancard is not matching");
		    return false;
		   }
	}


	@Override
	public boolean validateAccountType(String accountType) {
		 if(accountType.equals("savingsaccount")) {
			    accountType="savingsaccount";
			    return true;}
			    else if(accountType.equals("currentaccount")){
			     accountType="Currentaccount";
			     return true;}
			    else {
			     System.out.println("please enter correct details");
			   }
			   return false;
			  }
	


	@Override
	public boolean validateEMail(String eMail) {
		 Pattern pattern=Pattern.compile("[a-z]{2,7}@gmail.com");
		   Matcher matcher=pattern.matcher( eMail);
		   if(matcher.matches()) {
		  // log.info("email Matches"+ eMail);
		    return true;
		   }
		   else
		   {
		    //log.info("email is not matching");
		    return false;
		   }
	}


	@Override
	public boolean validateOpeningBalance(int openingBalance) {
		if(openingBalance==1000) {
		    openingBalance=1000;
		    return true;
		   }
		   else {
		    System.out.println("please enter valid amount");
		   
		   return false;
		  }
	}
	

	@Override
	public int addinfo(NewAccount newAccount) throws OnlineBankingException {
		daoobj=new OnlineBankingDao();
		return daoobj.addinfo(newAccount);
	}

	@Override
	public List<Transaction> retrieveAllTranInfo() throws SQLException {
		daoobj=new OnlineBankingDao();
		return daoobj.retrieveAllTranInfo();
	}

	@Override
	public List<Transaction> getMonthlyTransactions(int month,int year1) throws SQLException {
		daoobj=new OnlineBankingDao();
		//System.out.println(d.getMonthlyTransactions(month));
		return daoobj.getMonthlyTransactions(month,year1);
	}

	@Override
	public List<Transaction> getDayTransactions(String day) throws SQLException {
		daoobj=new OnlineBankingDao();
		System.out.println("day");
		return daoobj. getDayTransactions(day);
	}

	@Override
	public List<Transaction> getYearlyTransactions(int year) throws SQLException {
		daoobj=new OnlineBankingDao();
		return daoobj.getYearlyTransactions(year);
	}

	@Override
	public int request1(int accountId, String description) throws OnlineBankingException {
		daoobj=new OnlineBankingDao();
		return daoobj.request1(accountId,description);

}

	@Override
	public int Request3(int accountId, String description) throws OnlineBankingException {
	daoobj=new OnlineBankingDao();	
	return	daoobj.Request3(accountId,description);
	}


	@Override
	public boolean validateLoginId(int loginId) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean validatePassWord(int loginId) {
		// TODO Auto-generated method stub
		return false;
	}



	
	// login DUMMYYYYYYYYYYY
	public int validateCredentials() throws OnlineBankingException {
	int id;
	String pass;
	CustomerSignUp credBean=null;
	
	daoobj=new OnlineBankingDao();    
	do{
			//System.out.println("enter username");
			id=sc.nextInt();	      
			System.out.println("enter password");
			pass=sc.next();   
			daoobj=new OnlineBankingDao(); 
			
			
			credBean=daoobj.validateCredentials(id);
			if(credBean.equals(null)) {
				System.out.println("Please enyter valid credentials");
			}
			
			/*System.out.println((id==credBean.getUserId()) && (pass.equals(credBean.getLoginPassword())));
			System.out.println(credBean.getLoginPassword());*/
			
			
			if(id!=credBean.getUserId()) {
					if(!pass.equals(credBean.getLoginPassword()) ) {
				
				System.out.println("invalid credentials");
					}
			}
			
			
	}while((id!=credBean.getUserId()) && !(pass.equals(credBean.getLoginPassword())));
	
	
	
	return id;
	
	}

	@Override
	public int retriveAccountId(int loginId) throws OnlineBankingException {
		
		return daoobj.retriveAccountId(loginId);
	}	
	    
	    
	@Override
	public List<Payee> retrivePayeeDetails(int accountId) throws OnlineBankingException {
	
		return daoobj.retrivePayeeDetails(accountId);
	}


	@Override
	public int storepayeeDetails(int accountId, int payeeAccountId, String nickname) throws OnlineBankingException {
		
		return daoobj.storepayeeDetails(accountId,payeeAccountId,nickname);
	}


	

	@Override
	public void updatepayeeaccountbal(int payeeaccountid,int transactionAmount) throws OnlineBankingException {
		daoobj.updatepayeeaccountbal(payeeaccountid,transactionAmount);
		
	}


	@Override
	public void updatepayeraccountbal(int accountid,int transactionAmount) throws OnlineBankingException {
		daoobj.updatepayeraccountbal(accountid,transactionAmount);
		
	}


	@Override
	public void fundTransfer(int transaction_id, int accountId, int payeeaccountid, int transactionAmount) throws OnlineBankingException {
		daoobj.fundTransfer(transaction_id,accountId,payeeaccountid,transactionAmount);
		
	}


	@Override
	public String retrivetransactionpwd(int accountId) throws OnlineBankingException {
		
		return daoobj.retrivetransactionpwd(accountId);
	}

	@Override
	public int checkpayeeAccountId(int payeeAccountId) throws OnlineBankingException {
		int result=daoobj.checkpayeeAccountId(payeeAccountId);
		return result;
	}


	@Override  /* case 7*/
	public void updatetransaction(int transaction_id, String transdesc, int transactionAmount, int payeeaccountid,
			String string) throws OnlineBankingException {
		daoobj.updatetransaction(transaction_id,transdesc,transactionAmount,payeeaccountid,string);
		
	}

		   
	
	


}
