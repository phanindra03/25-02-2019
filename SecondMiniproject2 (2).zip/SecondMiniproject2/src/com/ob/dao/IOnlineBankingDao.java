package com.ob.dao;

import java.sql.SQLException;
import java.util.List;

import com.ob.dtobean.AccountMaster;
import com.ob.dtobean.CustomerSignUp;
import com.ob.dtobean.NewAccount;
import com.ob.dtobean.Payee;
import com.ob.dtobean.ServiceTracker;
import com.ob.dtobean.Transaction;
import com.ob.exception.OnlineBankingException;


public interface IOnlineBankingDao {

	abstract CustomerSignUp validateCustomerLoginDetails(int custuserid, String custpassword) throws OnlineBankingException;
	abstract int customerOpeningBalance(int accountId) throws OnlineBankingException;
	abstract int request(int acc_id, String description) throws OnlineBankingException;
	abstract String retrieveServiceTrackerByAccountId(int accountId) throws OnlineBankingException;
	abstract int customerSignUp(CustomerSignUp obs) throws OnlineBankingException;
	abstract int updateLoginPassword(int accountid,String loginPassword) throws OnlineBankingException;
	abstract int serviceTrackerId(int accountId,String newCheck) throws OnlineBankingException;
	abstract int request1(int accountId, String description) throws OnlineBankingException;
	abstract int Request3(int accountId, String description) throws OnlineBankingException;
	//*******************admin***********************
	abstract List<Transaction> getMonthlyTransactions(int month,int year1) throws SQLException;
	abstract List<Transaction> getYearlyTransactions(int year) throws SQLException;
	abstract List<Transaction> retrieveAllTranInfo() throws SQLException;
	abstract int addinfo(NewAccount newAccount) throws OnlineBankingException;
	abstract List<Transaction> getDayTransactions(String day) throws SQLException;
	//*************************ends**********************
	
	
	
	

	abstract CustomerSignUp validateCredentials(int id) throws OnlineBankingException ;
	abstract int retriveAccountId(int loginId) throws OnlineBankingException;


	//**********************************************/
	abstract void updatepayeeaccountbal(int payeeaccountid,int transactionAmount) throws OnlineBankingException ;    /* case 7  update in user table   */
	//**********************************************/
	abstract void updatepayeraccountbal(int accountId,int transactionAmount) throws OnlineBankingException;    /* case 7  update in user table   */
	//******************************************/
	abstract void fundTransfer(int transaction_id, int accountId, int payeeaccountid, int transactionAmount) throws OnlineBankingException;  /*  case 7 fund transfetr  */
	//*********************************************/
	abstract String retrivetransactionpwd(int accountId) throws OnlineBankingException;     /*     case 7    transaction password  from user table */
	//**************************************************/
	abstract List<Payee> retrivePayeeDetails(int accountId)  throws OnlineBankingException;       /*     case 7 from payee table    */
	//***********************************************/
	abstract int storepayeeDetails(int accountId, int payeeAccountId, String nickname) throws OnlineBankingException;    /*    case 7  to payee table   */
	//***********************************************/
	abstract int checkpayeeAccountId(int payeeAccountId) throws OnlineBankingException;               /*    case 7   from master table   */
	//******************************************/
	abstract void updatetransaction(int transaction_id, String transdesc, int transactionAmount, int payeeaccountid,
			String string) throws OnlineBankingException;                             /*    case 7 from transaction table  */
	

	
	
	
	

	
	
	

	

	

}
