package com.ob.dao;

public interface IQueryMapper {
     // Account Master
    String ACCOUNT_MASTER_INSERT_QRY="INSERT into AccountMaster values(ac_seq1.NEXTVAL,?,?,SYSDATE)";
    String RETRIVE_BY_AccountID_QRY="SELECT accseq.currval from dual ";
    //Customer Master
     String Customer_INSERT_QRY="INSERT into Customer values(ac_seq1.CURRVAL,?,?,?,?,?,?,?)";
     String RETRIVE_BY_CustomerID_QRY="SELECT CoustomerId from Customer where CustomerId=? ";
     String CUSTOMER_update_Qry="update  customer set  address=? where account_id=?";
     String CUSTOMER_mobileupdate_Qry="update  customer set   CUSTERMOBNUM=? where ACCOUNT_ID=?";
     String CUSTOMER_updatemobile_Qry="Update customer set  custermobnum=? where account_id=?";
     String RETRIVE_BY_OPENINGBAL_QRY="SELECT account_balance from account_master where account_id=?";
 String ServiceTracker_INSERT_QRY="insert into  service_tracker values(service_id.nextval,?,?,SYSDATE,?)";
String RETRIVE_BY_ServiceTrackerID_QRY="SELECT SERVICE_STATUS from Service_Tracker where  Service_Id=?";
     //usertable
      String Usertable_INSERT_QRY=" insert into user_table values(?,?,?,?,?,?)";
      String RETRIVE_BY_UserID_QRY="SELECT * from user_table where  user_id=? and LOGIN_PASSWORD=?";
      
     // fund_transfer
      String fundTransfer_INSERT_QRY="INSERT into fund_transfer values(ft_seq1.NEXTVAL,ac_seq1.CURRVAL,?,SYSDATE,?)";
      String RETRIVE_BY_fundTransfeID_QRY="SELECT ServiceTrackerId from fund_transfer where  fundTransferId=?";
     // payee table
      String payee_table_Qry="Select * from payeeTable";
      //transactions table
      String insert_qry = "insert into customer values(accseq.nextval,?,?,?,?,?,?,?)";
  	  String retrieve_month = "SELECT * FROM transactions WHERE to_char(dateoftransaction,'MM') = ?  and to_char(dateoftransaction,'YYYY')=?";
  	  String retrieve_day ="SELECT * FROM transactions WHERE dateoftransaction = ?";
  	  String retrieve_year ="SELECT * FROM transactions WHERE to_char(dateoftransaction,'YYYY') = ?";
  	  String retrieveall = "SELECT * FROM transactions ";
  	  
      String Update_PASSWORD="update user_table set login_Password=? where account_Id=?";
	  String RETRIVE_PAYEE_ID="select payee_account_id,nick_name from payee_table where account_id=?";
	  String PAYEE_INSERT_QRY = "insert into payee_table values(?,?,?)";
	  
	  
	  String Dummy_Query="select ACCOUNT_ID from user_table where  USER_ID=?";
	  
	  String SELECT_SERVICE_TRACKING_ID=" SELECT service_id.CURRVAL FROM DUAL";
      
	  String VALIDATE_CREDENTIALS=" SELECT * FROM USER_TABLE WHERE USER_ID=?";
	
	  String RETRIVE_ACCOUNTID = "select account_id from user_table where user_id=?";
	  //********************************
	  String CUSTOMER_INSERT_QRY ="insert into customer values(?,?,?,?,?,SYSDATE,jdbc1_seq1.NEXTVAL)" ;/**/
		//String USER_INSERT_QRY ="insert into account_master values" ;
		
		
		String RETRIVE_PAYEE_ACCOUNTID = "SELECT count(*) from Payee_table WHERE payee_account_Id = ?";/**/
		String RETRIVE_TRANSACTION_PWD = "select transaction_password from user_table where account_id=?";
		String INSERT_TRANSACTION = "insert into transactions values(?,?,SYSDATE,?,?,?)";/**/
		String INSERT_FUND_TRANSFER = "insert into fund_transfer values(?,?,?,SYSDATE,?)";/**/
		String UPDATE_PAYEE_ACCOUNTBAL = "update account_master set account_balance=? where account_id=?";/**/
		String UPDATE_PAYER_ACCOUNTBAL = "update account_master set account_balance=? where account_id=?";/**/
		String RETRIVE_ACCOUNT_BAL = "select account_balance from account_master where account_Id=?";/**/
		
}


